def volume_bola(radius):
    pi = 22 / 7
    return (4 / 3) * pi * radius