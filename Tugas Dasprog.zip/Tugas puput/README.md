# Tugas Dasar Pemrogramman

Name : Adam Gumilang

NIM : 20230040296

Class : TI23C
